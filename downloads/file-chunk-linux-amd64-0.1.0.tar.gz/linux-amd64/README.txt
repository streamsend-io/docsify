StreamSend File-chunk Pipeline - Linux AMD64 Release

This package contains:
- uploader: The StreamSend uploader utility
- downloader: The StreamSend downloader utility
 - librdkafka shared libraries: Required for Kafka connectivity
- install.sh: Installation script

Installation:
1. Extract this archive
2. Run the installation script: ./install.sh

Requirements:
- Linux with AMD64 architecture
- libssl3, libsasl2-2, libzstd1 (install with your package manager if needed)

For documentation, visit: https://docs.streamsend.io
