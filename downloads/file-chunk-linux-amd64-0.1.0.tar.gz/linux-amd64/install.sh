FROM debian:bookworm-slim

# Install runtime dependencies
RUN apt-get update && apt-get install -y \
    libssl3 libsasl2-2 libzstd1 ca-certificates \
    inetutils-ping netcat-openbsd curl \
    && rm -rf /var/lib/apt/lists/*

# Create client config directory and file
RUN mkdir -p /etc/kafka
RUN echo "ssl.ca.location=/etc/ssl/certs/ca-certificates.crt" > /etc/kafka/client.properties

# Copy librdkafka from build
COPY librdkafka.so* /usr/lib/
RUN ldconfig

# Copy downloader and verify libraries
COPY downloader /usr/local/bin/downloader
RUN chmod +x /usr/local/bin/downloader
RUN ldd /usr/local/bin/downloader

# Point to the SSL config
ENV KAFKA_SSL_CA_LOCATION=/etc/ssl/certs/ca-certificates.crt

CMD ["/usr/local/bin/downloader", "--kafka-config-file=/etc/kafka/client.properties"]
