#!/bin/bash
set -e

# Copy binaries
sudo cp uploader /usr/local/bin/
sudo cp downloader /usr/local/bin/

# Copy libraries
sudo cp librdkafka.so* /usr/lib/
sudo ldconfig

# Make executable
sudo chmod +x /usr/local/bin/uploader
sudo chmod +x /usr/local/bin/downloader

echo "StreamSend file-chunk pipeline installed successfully!"
echo "Run 'uploader --help' or 'downloader --help' for usage information."
