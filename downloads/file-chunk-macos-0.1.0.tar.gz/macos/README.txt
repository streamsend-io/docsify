StreamSend File-chunk Pipeline - macOS Release

This package contains:
- uploader: The StreamSend uploader utility
- downloader: The StreamSend downloader utility
- install.sh: Installation script

Installation:
1. Extract this archive
2. Run the installation script: ./install.sh

Requirements:
- macOS 10.15 or later
- librdkafka (can be installed with Homebrew: brew install librdkafka)

For documentation, visit: https://docs.streamsend.io
