StreamSend File-chunk Pipeline - Windows Release

This package contains:
- uploader: The StreamSend uploader utility
- downloader: The StreamSend downloader utility
- install.sh: Installation script

Installation:
1. Extract this archive
2. Run the installation script: ./install.sh

Requirements:
- Windows 10 or later (64-bit)
- No additional dependencies required (statically linked)

For documentation, visit: https://docs.streamsend.io
